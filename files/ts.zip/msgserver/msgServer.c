#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>   
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>   
#include <arpa/inet.h>   
#include <sys/wait.h>

#define BACKLOG 10


int main(void)
{
	int sockfd, new_fd;
	struct sockaddr_in my_addr;
	struct sockaddr_in their_addr;
	struct servent *se;
	int sin_size=0;
	int yes = 1;

	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("socket");
		exit(1);
	}

	if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
	{
		perror("setsockopt");
		exit(1);
	}

	my_addr.sin_family = AF_INET;
	my_addr.sin_port = 60000;
	my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	memset(&(my_addr.sin_zero), '\0', 8);

	if(bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
	{
		perror("bind");
		exit(1);
	}

	if(listen(sockfd, BACKLOG) == -1) 
	{
		perror("listen");
		exit(1);
	}

	while(1)
	{

		sin_size=sizeof(struct sockaddr);
		if((new_fd = accept(sockfd, (struct sockaddr *) &their_addr, (socklen_t*) &sin_size)) == -1)
		{
			perror("accept");
			continue;
		}

		printf("server : got connection from %s \n", inet_ntoa((struct in_addr)their_addr.sin_addr));

		if(!fork())
		{
			close(sockfd);
 			process_request(sockfd, their_addr.sin_addr);
			close(new_fd);
			exit(0);
		}
		close(new_fd);

		while(waitpid(-1, NULL, WNOHANG) > 0);
	}

	return 0;
}

process_request(int new_fd,struct in_addr caddr)
{
	char filename[20];
	char buf[500];
	int n;
	FILE *fp;

	n=recv(new_fd,buf, 500,0);
	buf[n]='\0';
	sprintf(filename,"cl-%s",inet_ntoa(caddr));
	printf("%s is creat\n",filename);
	if((fp=fopen(filename,"w"))==NULL) {
	 	perror("fopen");
		return 0;
	}
	fputs(buf,fp);
	fclose(fp);
	
}
