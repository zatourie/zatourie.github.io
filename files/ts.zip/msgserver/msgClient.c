#include <stdio.h>
#include <stdlib.h>
/* #include <unistd.h> */
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
/* #include <netinet/in.h> */

#define MAXDATASIZE 100

int main(int argc, char *argv[])
{
	int sockfd, numbytes; 
	char buf[MAXDATASIZE];
	struct hostent *he;
	struct servent *se;
	struct sockaddr_in their_addr;

    if(argc != 2)
	{
		fprintf(stderr, "usage : client hostname \n");
		exit(1);
    }

    if((he = gethostbyname(argv[1])) == NULL)
	{
		perror("gethostbyname");
		exit(1);
	}
 
	if(sockfd = socket(AF_INET, SOCK_DGRAM, 0) == -1)
	{
		perror("socket");
		exit(1);
	}

	their_addr.sin_family = AF_INET;
	their_addr.sin_port = htons(60000);
	their_addr.sin_addr = *((struct in_addr *)he->h_addr);     
	memset(&(their_addr.sin_zero), '\0',8);

	printf("[ %s ]\n", inet_ntoa(their_addr.sin_addr));

	if(connect(sockfd, (struct sockaddr *)&their_addr, sizeof(struct sockaddr)) == -1) 
	{
		perror("connect");
		exit(1);
	}

	process_request(sockfd);
	close(sockfd);

	return 0;
}


/* Ű���忡�� "quit" ���ڿ��� �Էµ� ������ �Էµ� ���ڿ��� ��Ƽ� ������ �����ϱ� */
process_request(int sockfd)
{
	char buf[500];
	char line[80];

	while (1) {
		printf("> ");
		fgets(line,79, stdin);
		if(strcmp(line,"quit")==0)
			break;	
		if(strlen(buf) + strlen(line) >500)
			break;
		strcat(buf,line);
	}
	send(sockfd, buf,strlen(buf),0);


}
