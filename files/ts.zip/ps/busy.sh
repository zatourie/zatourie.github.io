#!/bin/bash
number=1
while true
do
	let number=number+1
done
