#!/bin/bash
while true
do
	echo "Your name? "
	read name
	echo "My Name is $name"
done
