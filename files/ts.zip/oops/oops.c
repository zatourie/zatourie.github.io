#include <linux/module.h>
#include <linux/init.h>

static int __init mydev_init(void)
{
    printk("mydev_init called\n");
    *((int*) 0x00) = 0x12345678;
    return 0;
}
static void __exit mydev_exit(void)
{
    printk("mydev_exit called\n");
}
module_init(mydev_init);
module_exit(mydev_exit);
MODULE_LICENSE("GPL");

