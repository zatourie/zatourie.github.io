int main()
{
	system("ifconfig lo down");
//	system("ifconfig `ifconfig | grep eth | awk '{ print $1 }'` down");
}
